INSERT INTO address (id, creation, content, nom) VALUES (1, CURRENT_TIMESTAMP(), '57 boulevard demorieux','jean');
INSERT INTO address (id, creation, content, nom) VALUES (2, CURRENT_TIMESTAMP(), '51 allee du gamay, 34080 montpellier','luc');
