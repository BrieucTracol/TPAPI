package APIBrieuc.ArtifactB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtifactBApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtifactBApplication.class, args);
	}

}
