package APIBrieuc.ArtifactB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtifactBApplicationTests {

	@Test
	void contextLoads() {
	}

}
